/*
Navicat MySQL Data Transfer

Source Server         : Mysql
Source Server Version : 50719
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2018-01-21 01:08:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(255) DEFAULT NULL,
  `t_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', 'a', '1');
INSERT INTO `student` VALUES ('2', 'b', '1');
INSERT INTO `student` VALUES ('3', 'c', '2');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `t_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('1', '张三');
INSERT INTO `teacher` VALUES ('2', '李四');
INSERT INTO `teacher` VALUES ('3', '王五');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `age` int(20) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1007 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'gyh', '20', '北京昌平霍营小区');
INSERT INTO `user` VALUES ('2', 'fcp', '24', '北京昌平霍营小区');
INSERT INTO `user` VALUES ('3', 'zhk', '24', '北京昌平霍营小区');
INSERT INTO `user` VALUES ('4', 'tq', '24', '北京朝阳');
INSERT INTO `user` VALUES ('5', 'yxj', '24', '北京朝阳');
INSERT INTO `user` VALUES ('9', 'lisi', '24', '北京');
INSERT INTO `user` VALUES ('1000', 'lisi1', '25', '南京');
INSERT INTO `user` VALUES ('1001', 'lisi1', '25', '南京');
INSERT INTO `user` VALUES ('1002', 'lisi2', '24', '北京');
INSERT INTO `user` VALUES ('1003', 'lixiaoxi', '23', '北京丰台');
INSERT INTO `user` VALUES ('1004', 'lixiaohong', '22', '未知');
INSERT INTO `user` VALUES ('1005', 'lixia', '22', '北京');
INSERT INTO `user` VALUES ('1006', null, null, null);

-- ----------------------------
-- Table structure for user_my
-- ----------------------------
DROP TABLE IF EXISTS `user_my`;
CREATE TABLE `user_my` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `age` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_my
-- ----------------------------
INSERT INTO `user_my` VALUES ('1', 'gyh', '24');
INSERT INTO `user_my` VALUES ('2', 'fcp', '24');
INSERT INTO `user_my` VALUES ('3', 'zhk', '24');
INSERT INTO `user_my` VALUES ('4', 'tq', '24');
INSERT INTO `user_my` VALUES ('5', 'yxj', '24');
INSERT INTO `user_my` VALUES ('6', 'lisi', '24');
INSERT INTO `user_my` VALUES ('7', 'lisi1', '25');
INSERT INTO `user_my` VALUES ('9', 'lisi2', '24');
INSERT INTO `user_my` VALUES ('10', 'kyp', '28');
INSERT INTO `user_my` VALUES ('11', 'kp', '26');
INSERT INTO `user_my` VALUES ('12', 'yqc', '27');
