// 客户端数据交互Js
var isWebviewFlag = false;

// 设置启用 webView 首页面并加装成功
function setWebViewFlag() {
    isWebviewFlag = true;
}

/**
 * 页面加载完毕 触发页面数据采集
 */
window.addEventListener('load', function () {
    var nowurl = document.URL;
    var fromurl = document.referrer;
    var loadTime = 0;
    var ST = setInterval(function () {
        if (performance || performance.timing) {
            loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
        }
        if (loadTime > 0 && isWebviewFlag) {
            var jsonData = {
                "jsPageTitle": document.title,
                "jsPageTime": loadTime,
                "jsNowPageUrl": nowurl,
                "jsFromUrl": fromurl
            };
            PeopleAgent.jsData(jsonData);
            clearInterval(ST);
        }
    }, 50);

});


// 全局异常采集
window.addEventListener("error", function (evt) {
    var cTime = new Date().getTime();
    var error = evt.error || {};
    var eStack;
    if (evt.error) {
        eStack = error.stack;
    } else {
        // 兼容 ios9
        eStack = evt.filename + ":" + evt.lineno + ":" + evt.colno;
        // eStack =  evt.deepPath; // ios 9 未实现
    }
    var SI = setInterval(function () {
        if (isWebviewFlag) {
            var value = {
                message: evt.message,
                stack: eStack,
                reportTime: cTime,
                pageTitle: document.title
            };
            PeopleAgent.jsError(value);
            clearInterval(SI);
        }
    }, 300)
});

// js 2 native data  数据封装到url中
function js2NativeData(url) {
    var iFrame;
    iFrame = document.createElement("iframe");
    iFrame.setAttribute("src", url);
    iFrame.setAttribute("style", "display:none;");
    iFrame.setAttribute("height", "0px");
    iFrame.setAttribute("width", "0px");
    iFrame.setAttribute("frameborder", "0");
    document.body.appendChild(iFrame);
    iFrame.parentNode.removeChild(iFrame);
    iFrame = null;
}

// html 数据封装成Json
function data2Json(funName, args) {

    var commend = {
        functionName: funName,
        arguments: args
    };
    var jsonStr = JSON.stringify(commend);
    var url = "people:" + jsonStr;

    js2NativeData(url);

}


// 客户端交互
var PeopleAgent = {
    /**
     * 自定义事件数量统计
     *
     * @param eventId
     *            String类型.事件ID，
     * @param eventLabel
     *            String类型.事件标签，事件的一个属性说明
     */
    onEventWithCustom: function (eventId, eventLabel) {
        if (isWebviewFlag) {
            var evJson = {
                key: eventId,
                value: eventLabel
            };
            data2Json("onEventWithCustom", [evJson]);
        }
    },
    /**
     * Js 错误日志
     * @param obj 异常信息
     */
    jsError: function (obj) {
        if (isWebviewFlag) {
            data2Json("jsError", [obj])
        }
    },

    /**
     * 页面数据
     * @param obj 正常数据
     */
    jsData: function (obj) {
        if (isWebviewFlag) {
            data2Json("jsData", [obj])
        }
    }
};

