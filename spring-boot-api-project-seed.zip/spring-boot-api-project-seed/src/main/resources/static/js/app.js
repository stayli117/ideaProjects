$(document).ready(function () {
    $.ajax({
        type: "get",//请求方式get/post
        url: "http://localhost:8090/apm/lists",//请求地址
        dataType: "json",//声明当前的响应为json格式，则success中的abc就
        //是解析后的js对象
        success: function (abc) {//abc==xhr.responseText或解析后的js对象
            console.log(abc)
        }
    });
    $.ajax({
        type: "post",//请求方式get/post
        url: "http://localhost:8090/apm/list",//请求地址
        date: "page=0&size=1",
        dataType: "json",//声明当前的响应为json格式，则success中的abc就
        //是解析后的js对象
        success: function (abc) {//abc==xhr.responseText或解析后的js对象
            console.log(abc)
        }
    })
});



