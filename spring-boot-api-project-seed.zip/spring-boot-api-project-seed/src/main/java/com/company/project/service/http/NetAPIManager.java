package com.company.project.service.http;


import com.company.project.service.http.anno.BaseUrl;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;


import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;


/**
 * Created by yhgao on 2018/2/9.
 */

public class NetAPIManager {


    private Gson gson;
    private OkHttpClient client;


    private static interface Signal {
        NetAPIManager MANAGER = new NetAPIManager();
    }

    private NetAPIManager() {
    }

    public static NetAPIManager getInstance() {
        return Signal.MANAGER;
    }

    private Retrofit mRetrofit;

    public void init() {
        //配置你的Gson
        gson = new GsonBuilder()
                //配置你的Gson
                .setDateFormat("yyyy-MM-dd hh:mm:ss")
                .create();


        ConnectionPool pool = new ConnectionPool(5, 30, TimeUnit.SECONDS);
        client = new OkHttpClient.Builder()
                .connectionPool(pool)
                .build();

        mRetrofit = new Retrofit.Builder()
                .baseUrl("http://www.baidu.com")
                .client(client)
                .build();
    }

    public Retrofit getRetrofit() {
        return mRetrofit;
    }

    public Retrofit getRetrofit(String baseUrl) {
        return mRetrofit.newBuilder()
                .baseUrl(baseUrl)
                .client(client)
                .build();
    }

    private final Map<Class,Proxy> serviceCache = new ConcurrentHashMap<>();

    public <T> T create(Class<T> clazz) {
        if (!clazz.isInterface()) {
            throw new IllegalArgumentException("API declarations must be interfaces.");
        }
        BaseUrl annotation = clazz.getAnnotation(BaseUrl.class);
        if (annotation==null){
            throw new IllegalArgumentException("No BaseUrl annotation exists");
        }
        String baseUrl = annotation.value();
        if (baseUrl.length() > 1){
            throw new IllegalArgumentException("BaseUrl is null");
        }


        Proxy result = serviceCache.get(clazz);
        if (result != null) return (T) result;
        synchronized (serviceCache) {
            result = serviceCache.get(clazz);
            if (result == null) {
                Retrofit retrofit = mRetrofit.newBuilder()
                        .baseUrl(baseUrl)
                        .client(client)
                        .build();
                result = (Proxy) retrofit.create(clazz);
                serviceCache.put(clazz, result);
            }
        }
//        CloudFragment t = getT(CloudFragment.class);

        return (T) result;
    }



//    public static <K extends T,T extends BaseFragment> K getT(Class<K> clazz){
//
//        T t = (T) new BaseFragment();
//
//        K k = null;
//        String name =clazz.getSimpleName();
//        if ("MusicFragment".equals(name)){
//            k= (K) new MusicFragment();
//        }
//
//        Bundle args = new Bundle();
//
//        t.setArguments(args);
//        return k;
//
//    }

}
