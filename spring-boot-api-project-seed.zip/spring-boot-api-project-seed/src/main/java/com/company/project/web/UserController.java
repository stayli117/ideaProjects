package com.company.project.web;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.company.project.core.Result;
import com.company.project.core.ResultGenerator;
import com.company.project.model.User;
import com.company.project.service.UserService;
import com.company.project.util.ApmConfig;
import com.company.project.util.StreamUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by CodeGenerator on 2017/11/19.
 */
@RestController
@RequestMapping("/apm")
public class UserController {
    @Resource
    private UserService userService;

    @PostMapping("/add")
    public Result add(User user) {
        userService.save(user);
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 4、通过@PathVariable获取路径中的参数
     *
     * @param username
     * @param password
     * @return 例如，访问http://localhost/SSMDemo/templates.demo/addUser4/lixiaoxi/111111 路径时，
     * 则自动将URL中模板变量{username}和{password}绑定到通过@PathVariable注解的同名参数上，
     * 即入参后username=lixiaoxi、password=111111。
     */
    @RequestMapping(value = "/addUser/{username}/{password}/{addr}", method = RequestMethod.GET)
    public Result addUser4(@PathVariable String username, @PathVariable String password, @PathVariable String addr) {
        System.out.println("username is:" + username);
//        if (null == username || username.length() < 1) {
//            return ResultGenerator.genFailResult("username is null");
//        }
        System.out.println("password is:" + password);
//        if (password < 0) {
//            return ResultGenerator.genFailResult("password < 0 ?");
//        }
        System.out.println("addr is:" + addr);
//        if (null == addr || addr.length() < 1) {
//            return ResultGenerator.genFailResult("addr is null");
//        }

        User user = new User();
        user.setName(username);
        user.setAge(password);
        user.setAddr(addr);
        userService.save(user);
        return ResultGenerator.genSuccessResult("添加成功");
    }


    @PostMapping("/delete")
    public Result delete(@RequestParam Integer id) {
        userService.deleteById(id);
        return ResultGenerator.genSuccessResult();
    }

    @GetMapping("/get")
    public Result get(@RequestParam Integer id) {

        System.out.println("--> " + id);

        return ResultGenerator.genSuccessResult();
    }

    @PutMapping("/put")
    public Result put(@RequestParam Integer id) {

        System.out.println("--> put " + id);

        return ResultGenerator.genSuccessResult();
    }

    @PostMapping("/post")
    public Result post(@RequestParam Integer id) {

        System.out.println("--> " + id);

        return ResultGenerator.genSuccessResult();
    }


    @PostMapping("/update")
    public Result update(User user) {
        userService.update(user);
        return ResultGenerator.genSuccessResult();
    }

    @PostMapping("/detail")
    public Result detail(@RequestParam Integer id) {
        User user = userService.findById(id);
        return ResultGenerator.genSuccessResult(user);
    }

    @PostMapping("/list")
    public Result list(@RequestParam(defaultValue = "0") Integer page, @RequestParam(defaultValue = "0") Integer size) {
        PageHelper.startPage(page, size);
        List<User> list = userService.findAll();
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }

    @RequestMapping("/lists")
    public Result list() {
        PageHelper.startPage(1, 2);
        List<User> list = userService.findAll();
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }

    @RequestMapping(value = "/dataCollectionConfig", method = RequestMethod.GET)
    public Result dataCollectionConfig(@RequestParam String appKey) {
//        System.out.println("AppKey --> " + appKey);
//        JSONObject jo = new JSONObject();
//        jo.put("status", 0);
//
//        JSONArray array = new JSONArray();
//        JSONObject jo1 = new JSONObject();
//        JSONArray array1 = new JSONArray();
//        array1.add("Imei");
//        array1.add("CPUName");
//        array1.add("CPUArch");
//        array1.add("MobileNo");
//        array1.add("LoginType");
//        jo1.put("key", "F1");
//        jo1.put("value", array1);
//        array.add(jo1);
//        JSONObject jo2 = new JSONObject();
//        jo2.put("key", "DeviceInfoA");
//        jo2.put("value", 33948672);
//
//        jo.put("data", array);
//        JPushController.sendSystemInfo();
//
        Result result = ResultGenerator.genPolicySuccessResult();
        result.setStatus(200);
        return result;
    }

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final ConcurrentMap<String, Integer> map = new ConcurrentHashMap<>();

    @PostMapping("/collectedData")
    public Result collectedData(String reqData, String appKey, @RequestHeader HttpHeaders header) {
//        System.out.println("appKey--> " + appKey);
//        System.out.println("reqData--> " + reqData);


        Result result = ResultGenerator.genResult();
        result.setStatus(0).setPolicyVersion("0");
//        if (!"6c1575c474cb29e50bd395a031282b86adf59455".equals(appKey)) {
        logger.info("--------------------------------\n");
        logger.debug("header ----------> ");
        logger.debug(header.toString());
        logger.debug("request ----------------->");
        logger.debug(appKey + " ------------- " + reqData);
        logger.debug("长度----- " + reqData.length());
        reqData = reqData.replaceAll("%2B", "\\+");
        String gzip = StreamUtils.dComForGzip(reqData);
        if (map.containsKey(reqData)) {
            int integer = map.get(reqData);
            integer++;
            map.put(reqData, integer);
            logger.error(reqData + "-> " + integer + "  \n--> " + gzip);
        } else {
            map.put(reqData, 1);
        }
        logger.debug(appKey + " ------------- " + gzip);
        logger.debug(" 长度------------- " + gzip.length());
        logger.debug("Response->  " + result.toString());
        logger.info("----------------------------------\n");
//        }


        return result;
    }


}
