package com.company.project.core;

import com.company.project.util.ApmConfig;
import com.google.gson.JsonArray;

/**
 * 响应结果生成工具
 */
public class ResultGenerator {
    private static final String DEFAULT_SUCCESS_MESSAGE = "SUCCESS";

    public static Result genResult() {
        return new Result();
    }

    public static Result genSuccessResult() {
        return new Result()
                .setStatus(ResultCode.SUCCESS)
                .setMessage(DEFAULT_SUCCESS_MESSAGE);
    }

    public static Result genSuccessResult(Object data) {
        return new Result()
                .setStatus(ResultCode.SUCCESS)
                .setMessage(DEFAULT_SUCCESS_MESSAGE)
                .setData(data);
    }

    public static Result genFailResult(String message) {
        return new Result()
                .setStatus(ResultCode.FAIL)
                .setMessage(message);
    }

    public static Result genPolicySuccessResult() {
        return new PolicyResult()
                .setTime("0")
                .setType("1")
                .setAppStatus(1)
                .setIsWIFI(0)
                .setPolicyVersion("0");
    }
}
