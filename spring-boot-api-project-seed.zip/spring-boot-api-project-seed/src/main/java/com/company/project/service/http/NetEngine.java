package com.company.project.service.http;

import com.company.project.model.WeatherBean;
import okhttp3.*;

import java.io.IOException;

public class NetEngine {

    private static final OkHttpClient client;

    static {
        client = new OkHttpClient.Builder().build();
    }


    public static void get(String city, Callback callback) {
        Call call = client.newCall(new Request.Builder()
                .url("http://www.sojson.com/open/api/weather/json.shtml" + "?city=" + city)
                .get().build()
        );
        call.enqueue(callback);
    }



}
