package com.company.project.util;

/**
 * Created by people_yh_Gao on 2017/11/23.
 */
public interface ApmConfig {
    /**
     * SDK 默认采集策略
     */
    String defaultPolicy = "{\"status\":0," +
            "\"data\":[{\"key\":\"F1\"," +
            "\"value\":[\"Imei\",\"CPUName\",\"CPUArch\",\"MobileNo\",\"LoginType\"]}," +
            "{\"key\":\"DeviceInfoA\",\"value\":33948672}," +
            "{\"key\":\"DeviceInfoI\",\"value\":1580032}," +
            "{\"key\":\"F2\",\"value\":[\"appKey\",\"AV\",\"CA\",\"AN\",\"NewRegistration\"," +
            "\"Device_ID\",\"OS\",\"SY\",\"MU\",\"EM\",\"DM\",\"VI\",\"TM\",\"UserId\",\"PN\"," +
            "\"OperationTime\",\"NT\",\"OperationPage\",\"PageSequence\",\"PageResponseTime\"," +
            "\"PageAction\",\"ServerIp\",\"PreOperationPage\",\"PostURL\",\"AvailMemory\",\"WebURL\"," +
            "\"OriginalURL\",\"OriginalTitle\",\"PostURLFull\",\"CustomEvent\",\"Location\",\"CPUTime\"," +
            "\"AppCPUTime\",\"KeyValues\",\"CAIUT\",\"CAIDT\"]}," +
            "{\"key\":\"OperationInfoA\",\"value\":963677743}," +
            "{\"key\":\"OperationInfoI\",\"value\":462799}," +
            "{\"key\":\"F3\"," +
            "\"value\":[\"appKey\",\"AV\",\"CA\",\"AN\",\"Device_ID\",\"OS\",\"SY\"," +
            "\"MU\",\"EM\",\"DM\",\"VI\",\"TM\",\"UserId\",\"PN\",\"OperationTime\"," +
            "\"NT\",\"AppLoginTime\",\"AppExitTime\",\"Location\",\"InstalledAPPs\"]}," +
            "{\"key\":\"UsageHabits\",\"value\":3}," +
            "{\"key\":\"F4\"," +
            "\"value\":[\"appKey\",\"AV\",\"CA\",\"AN\",\"Device_ID\",\"OS\",\"SY\"," +
            "\"MU\",\"EM\",\"DM\",\"VI\",\"TM\",\"UserId\",\"PN\",\"OperationTime\"," +
            "\"NT\",\"OperationPage\",\"PreOperationPage\",\"AvailMemory\",\"WebURL\"," +
            "\"AppLoginTime\",\"Location\",\"CPUID\",\"isRoot\",\"UIORI\",\"ReportTime\"," +
            "\"ErrorType\",\"ErrorInfo\",\"ErrorLog\",\"ThreadName\",\"BgRunService\"]}," +
            "{\"key\":\"ErrorInfo\",\"value\":223}]," +
            "\"time\":\"0\"," +
            "\"type\":1," +
            "\"isWiFi\":0," +
            "\"policyVersion\":0," +
            "\"appStatus\":1}";

}
