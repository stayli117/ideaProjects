package com.company.project.core;

import com.alibaba.fastjson.annotation.JSONField;

public class PolicyResult extends Result {


    @JSONField(ordinal = 8)
    private String time;
    @JSONField(ordinal = 5)
    private String type;
    @JSONField(ordinal = 6)
    private int isWIFI;
    @JSONField(ordinal = 7)
    private int appStatus;

    public PolicyResult setAppStatus(int appStatus) {
        this.appStatus = appStatus;
        return this;
    }

    public PolicyResult setTime(String time) {
        this.time = time;
        return this;
    }

    public PolicyResult setType(String type) {
        this.type = type;
        return this;
    }

    public PolicyResult setIsWIFI(int isWIFI) {
        this.isWIFI = isWIFI;
        return this;
    }

    public String getTime() {
        return time;
    }

    public String getType() {
        return type;
    }

    public int getIsWIFI() {
        return isWIFI;
    }

    public int getAppStatus() {
        return appStatus;
    }
}
