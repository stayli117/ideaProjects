package com.company.project.service.http;


import com.company.project.service.http.anno.BaseUrl;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * 豆瓣 API 接口
 */
@BaseUrl("https://api.douban.com/")
public interface IDBApiInterface {


    static final String URL = "https://api.douban.com/v2/book/1220562";
    static final String BASE_URL = "https://api.douban.com/";
    static final String BASE_URL_BOOK_Con = "https://api.douban.com/v2/book/user/jinger/collections";

    // 指定参数刷新
    @GET("/v2/book/user/{userName}/collections")
    Call<Object> getUser2BookCollections(@Path("userName") String userName,
                                         @Query(value = "start") String start,
                                         @Query(value = "count") String count);

}
