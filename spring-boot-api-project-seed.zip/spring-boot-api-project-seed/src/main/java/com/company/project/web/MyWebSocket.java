package com.company.project.web;

import com.company.project.service.http.NetEngine;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

@ServerEndpoint(value = "/websocket/{userId}")
@Component
public class MyWebSocket {
    //静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
    private static int onlineCount = 0;

    //concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。
    private static CopyOnWriteArraySet<MyWebSocket> webSocketSet = new CopyOnWriteArraySet<MyWebSocket>();
    //concurrent包的线程安全Map，用来存放每个客户端对应的id,Session对象。
    private static ConcurrentHashMap<String, Session> webSocketMap = new ConcurrentHashMap<>();

    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;

//    /**
//     * 连接建立成功调用的方法
//     */
//    @OnOpen
//    public void onOpen(Session session) {
//        this.session = session;
//        webSocketSet.add(this);     //加入set中
//        addOnlineCount();           //在线数加1
////        System.out.println("有新连接加入！当前在线人数为" + getOnlineCount());
//        System.out.println("有新连接加入！当前在线人数为" + webSocketSet.size());
//        System.out.println("有新连接加入！当前新连接 ID " + session.getId());
//        System.out.println("有新连接加入！当前新连接 数据" + session.getQueryString());
//        Map<String, Object> properties = session.getUserProperties();
//        if (properties.size() > 0) {
//            for (Map.Entry<String, Object> entry : properties.entrySet()) {
//                System.out.println("有新连接加入！当前新连接 数据" + entry.getKey() + " : " + entry.getValue());
//            }
//
//        }
//        try {
//            sendMessage(webSocketSet.size() + "ok");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }


    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("userId") String userId) {
        this.session = session;
        webSocketSet.add(this);     //加入set中
        webSocketMap.put(userId, session);
        addOnlineCount();           //在线数加1
//        System.out.println("有新连接加入！当前在线人数为" + getOnlineCount());
        System.out.println("有新连接加入！当前在线人数为" + webSocketSet.size());
        System.out.println("有新连接加入！当前新连接 ID " + session.getId());
        System.out.println("有新连接加入！当前新连接 数据" + userId);


        try {
            sendMessage(webSocketSet.size() + "ok");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        webSocketSet.remove(this);  //从set中删除
        Map<String, String> map = session.getPathParameters();
        webSocketMap.remove(map.get("userId"));
        for (String user : webSocketMap.keySet()) {
            System.out.println(user);
        }
        subOnlineCount();           //在线数减1
        System.out.println("有一连接关闭！当前在线人数为" + getOnlineCount());
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("来自客户端的消息:" + message);
        Map<String, String> map = session.getPathParameters();
        String userId = map.get("userId");
        System.out.println("userId : " + userId);
        for (String user : webSocketMap.keySet()) {
            sendMessage(user + "你好，我是专属客服已收到您的消息 " + message, webSocketMap.get(user));
        }
        //群发消息
//        for (MyWebSocket item : webSocketSet) {
//            try {
//                item.sendMessage(message);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
    }

    private void sendMessage(String msg, Session session) {
        if (session.isOpen()) {
            session.getAsyncRemote().sendText(msg);
        }
    }

    /**
     * 发生错误时调用
     *
     * @OnError public void onError(Session session, Throwable error) {
     * System.out.println("发生错误");
     * error.printStackTrace();
     * }
     * <p>
     * <p>
     * public void sendMessage(String message) throws IOException {
     * this.session.getBasicRemote().sendText(message);
     * //this.session.getAsyncRemote().sendText(message);
     * }
     * <p>
     * <p>
     * /**
     * 群发自定义消息
     */
    public static void sendInfo(String message) throws IOException {
        for (MyWebSocket item : webSocketSet) {
            try {
                item.sendMessage(message);
            } catch (IOException e) {
                continue;
            }
        }
    }

    public void sendMessage(String message) throws IOException {
        session.getBasicRemote().sendText("服务端返回: " + message);
    }

    // 定时群发
    @Scheduled(cron = "0/120 * * * * ?") // 每20秒执行一次
    public void scheduler() {
        for (MyWebSocket webSocket : webSocketSet) {
            webSocket.sendMessage("当前天气", webSocket.session);
        }

//        NetEngine.get("北京", new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//
//            }
//        });
    }

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        MyWebSocket.onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        MyWebSocket.onlineCount--;
    }


}
