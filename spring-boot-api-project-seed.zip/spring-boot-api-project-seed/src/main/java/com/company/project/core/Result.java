package com.company.project.core;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.google.gson.JsonArray;

/**
 * 统一API响应结果封装
 */
public class Result {
    @JSONField(ordinal = 1)
    protected int status;
    @JSONField(ordinal = 3)
    protected String message;
    @JSONField(ordinal = 4)
    protected String policyVersion;
    @JSONField(ordinal = 2)
    protected Object data;


    public Result setStatus(ResultCode resultCode) {
        this.status = resultCode.status;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public Result setStatus(int status) {
        this.status = status;
        return this;
    }

    public String getPolicyVersion() {
        return policyVersion;
    }

    public String getMessage() {
        return message;
    }

    public Result setMessage(String message) {
        this.message = message;
        return this;
    }

    public Object getData() {
        return data;
    }

    public Result setData(Object data) {
        this.data = data;
        return this;
    }

    public Result setPolicyVersion(String policyVersion) {
        this.policyVersion = policyVersion;
        return this;
    }

    @Override
    public String toString() {
        Object o = JSON.toJSON(this);

        return JSON.toJSONString(this);
    }
}
