package com.company.project.web;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.resp.APIConnectionException;
import cn.jpush.api.common.resp.APIRequestException;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;

import cn.jpush.api.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

@Configuration
@EnableScheduling // 启用定时任务
public class JPushController {
    // 应用的key
    private static final String appKeyPT = "4a35c1a7aef6e3fc43339db9";
    // 应用的Secret
    private static final String masterSecretPT = "72e1857ed009d0aff91e8c6a";


    public void utilJson(String data, PrintWriter printWriter) {
        printWriter.write(data);
        printWriter.flush();
        printWriter.close();
    }

    public static PushPayload buildPushObject_android_and_ios(Map<String, String> map)
            throws UnsupportedEncodingException {
        String registrationId = map.get("registrationId");
        map.remove("registrationId");
        return PushPayload.newBuilder().setPlatform(Platform.android_ios())
                .setAudience(Audience.registrationId(registrationId))
                .setNotification(
                        Notification.newBuilder().setAlert("网页端推送登录")
                                .addPlatformNotification(AndroidNotification.newBuilder().setTitle("Android Title")
                                        .addExtras(map).build())
                                .addPlatformNotification(
                                        ((IosNotification.Builder) IosNotification.newBuilder().addExtras(map)).build())
                                .build())
                .setOptions(Options.newBuilder().setApnsProduction(false).build()).build();
    }


    public void sendSystemInfo() {
        int userId = 13;
        String phoneNum = "18567677596";
        // 3.1判断用户是否登录S盾
        String registrationIds = "190e35f7e07d771efca&1";
        if (StringUtils.isNotEmpty(registrationIds)) {
            String[] strs = registrationIds.split("&");
            String masterSecret = masterSecretPT;
            String appKey = appKeyPT;
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String createTime = format.format(new Date());

            // 3.3进行推送
            Map<String, String> map = new HashMap<String, String>();
            map.put("registrationId", strs[0]);
            map.put("phoneNum", phoneNum);
            map.put("webip", "0:0:0:0");
            map.put("address", "未知");
            map.put("createTime", createTime);
            map.put("flatform", "sDunWebServer");
            map.put("modelName", "系统消息");
            map.put("modelType", "System");
            map.put("timeOut", "1000");
            map.put("messageType", "2");
            map.put("messageId", "112");
            map.put("userId", userId + "");
            map.put("content", "S盾五期功能测试中。。。");
            JPushClient jpushClient = new JPushClient(masterSecret, appKey, 3);
            PushPayload payload = null;
            try {
                payload = buildPushObject_android_and_ios(map);
                PushResult result = jpushClient.sendPush(payload);
            } catch (APIConnectionException e) {
                e.printStackTrace();
            } catch (APIRequestException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }

    }


//    @Scheduled(cron = "0 */1 * * * ?") // 每20秒执行一次
    public void scheduler() {
        sendSystemInfo();
    }
}
