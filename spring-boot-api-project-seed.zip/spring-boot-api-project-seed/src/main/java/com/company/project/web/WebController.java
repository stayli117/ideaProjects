package com.company.project.web;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;


/**
 * Created by people_yh_Gao on 2017/10/26.
 */
@Controller
public class WebController {


    @RequestMapping("/login")
    public String test() {
        return "login";
    }

    @RequestMapping(value = "/view", method = RequestMethod.GET)
    public String getView() {
        return "test/index";
    }

    @RequestMapping(value = "/demo", method = RequestMethod.GET)
    public String hybrid() {
        return "demo/index";
    }

    @RequestMapping("info/more")
    public String page2() {
        return "redirect:/index.html";
    }

    @RequestMapping("info/more/2")
    public String page3() {
        return "index";
    }


    @RequestMapping("foo")
    public void handleFoo(HttpServletResponse response) throws IOException {
        response.sendRedirect("/index.html");
    }


    // inject via application.properties
    @Value("${welcome.message:test}")
    private String message = "Hello World";

    @RequestMapping("/")
    public ModelAndView welcome(Map<String, Object> model) {
        ModelAndView modelAndView = new ModelAndView("welcome");
        model.put("message", this.message);
        modelAndView.addAllObjects(model);
        return modelAndView;
    }

    @RequestMapping(value = "/index")
    public String index() {
        return "index";
    }


}
