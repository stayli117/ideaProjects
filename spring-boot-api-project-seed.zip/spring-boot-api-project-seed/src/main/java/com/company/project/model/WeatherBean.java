package com.company.project.model;

public class WeatherBean {
}
